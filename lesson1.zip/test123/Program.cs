﻿using System;

namespace test123
{
    class Program
    {
        static void Main(string[] args)
        {
            // int myInt; //декларация
            // int myInitInt = 30; // декларация с инициализация

            // myInt = 20; //инициализация

            // byte myByte = 100;
            // sbyte mySbyte = -100;

            // short myShort = 30000;

            // int age = 100;

            // double myDouble = 12.56464564;
            // float myFloat = 12.56464564F;

            // System.Console.WriteLine(myDouble);
            // System.Console.WriteLine(myFloat);

            // char myChar = 's';

            // bool isTrue = false;

            // string myString = " \" Hel\tlo\' Wor\nld \" ";



            // System.Console.WriteLine(myString);

            // System.Console.WriteLine("Enter the name");
            // string name = Console.ReadLine();
            // System.Console.WriteLine("Enter the age");
            // int age = Convert.ToInt32(Console.ReadLine());
            // System.Console.WriteLine("Hello " + 20);
            // System.Console.WriteLine("100" + 100);
            // System.Console.WriteLine("Привет, " + name + "\nТвой возраст " + age);

            // System.Console.WriteLine($"Привет, {name}\nТвой возраст{age}");
            // System.Console.WriteLine("Привет, {0}\nТвой возраст {1} {2}", name, age, 20);
            // System.Console.WriteLine(name);
            // System.Console.WriteLine(age);

            // Console.ReadKey();


            // System.Console.WriteLine(100L);
            // Console.WriteLine("Hello World!");

            // decimal myDecimal = 20/13M;
            // System.Console.WriteLine(myDecimal);

            // var myVar = 100;
            // dynamic myDynamic = 100;

            // // myVar = "sadasdas";

            // myDynamic = "dfasdsaxasascs";

            // object myObject = "dsaasxascdcsd";

            // int myIntObject = (int) myObject;



        }
    }
}
