namespace idetTest.Models
{
    public class PermisionDao
    {
        
    }
}