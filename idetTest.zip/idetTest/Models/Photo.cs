namespace idetTest.Models
{
    public class Photo
    {
        public int id{get;set;}
        public string path{get;set;}
    }
}