namespace idetTest.Models
{
    public class Image
    {
        public int id{get;set;}
        public string path{get;set;}
    }
}