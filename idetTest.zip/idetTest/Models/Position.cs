namespace idetTest.Models
{
    public class Position
    {
        public int id{get;set;}
        public string name{get;set;}
    }
}