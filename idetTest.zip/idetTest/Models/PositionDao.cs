namespace idetTest.Models
{
    public class PositionDao
    {
        
    }
}