namespace idetTest.Models
{
    public class Permision
    {
        public int id{get;set;}
        public string name{get;set;}
    }
}