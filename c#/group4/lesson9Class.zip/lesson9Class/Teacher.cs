using System;
namespace lesson9Class
{
    public class Teacher
    {
        
    }
}