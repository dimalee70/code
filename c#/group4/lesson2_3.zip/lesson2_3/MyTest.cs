using System;
namespace lesson2_3
{
    public class MyTest
    {
        public string name {get;set;}
    }
}