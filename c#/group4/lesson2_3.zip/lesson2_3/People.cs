using System;
namespace lesson2_3
{
    public class People<T>
    {
        public static T name;

    }
}