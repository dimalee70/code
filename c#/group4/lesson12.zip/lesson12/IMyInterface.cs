using System;

namespace lesson12
{
    public interface IMyInterface
    {
        void printHello();

        void printName(string name);

        void delete();
    
        // public string DefaultMethod()
        // {
        //     return "IMyInterface";
        // }

        
    }
}