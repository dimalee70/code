using System;
namespace lesson12
{
    public interface IBaseInterface
    {
        int getCount();
    
    }
}