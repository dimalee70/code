﻿using System;

namespace lesson11
{
    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");
            // string text = "hello";
            // System.Console.WriteLine(text.Length);
            // text.ToCharArray();
            // string.Join(" ", text);

            // WorkWithArr.className = "WorkWithArr";

            // System.Console.WriteLine(WorkWithArr.className);

            // int [] arr = {1,2,3,4,5,6,7,8};

            // WorkWithArr workWithArr = 
            //     WorkWithArr.newInstance(arr);

            // WorkWithArr workWithArr = new WorkWithArr(arr);


            // WorkWithArr workWithArr2 = new WorkWithArr(arr); 
            // WorkWithArr workWithArr3 = new WorkWithArr(arr);

            // workWithArr.printArr();

            string text = "Hello. My name is John";
            System.Console.WriteLine(text.HalfString());

            int t = 10;
            System.Console.WriteLine(t.HalfInt());
        }
    }
}
