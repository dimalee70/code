﻿using System;

namespace classes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");
            // MyPoint myPoint = new MyPoint();

            // MyPoint myPoint2 = new MyPoint(1,2,3);
            // // System.Console.WriteLine(myPoint2.getSum());

            // // System.Console.WriteLine( myPoint.print());
            // System.Console.WriteLine(myPoint2);  

            // Student student = new Student("Islam", "123456789",18);
            // // student.prinInfo();
            // // student.hello();

            // // String str = student.ToString();
            // // int age = student.age;
            // student.prinInfo();

            // Student.


            // string name = "dima";
            // string nameUpper = name.ToUpper();
            
            // int [] t = {1,2,3,4,5,6,7};
            // Array.Reverse(t); 
            String d = new String("Dmitriy");

            // int 
            // Int32 myInt = new Int32(10);



            Student.Reverse(ref d);

            Student student = new Student("dfsd","dfs",12);
            System.Console.WriteLine(d);
           
            // myPoint.x = 1
            // Object
        }
    }
}
