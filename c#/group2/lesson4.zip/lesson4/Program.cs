﻿using System;

namespace lesson4
{
    class Program
    {
        static void Main(string[] args)
        {

        
            // System.Console.WriteLine("Enter the char");
            // char c = Convert.ToChar(Console.ReadLine());

            // char? c3;
            // int? t = null;
            // if((int)c >= 65 && (int) c <= 90)
            // {
            //     c3 = (char)((int) c + 32);
            // }
            // else if((int) c >= 97 && (int) c <= 122)
            // {
            //     c3 = (char)((int) c - 32);
            // }
            // else
            // {
            //     c3 = null;
            // }
            // System.Console.WriteLine(c3);


            // char c2 = 'A';
            // char c3 = (char)((int) c2 + 32);
            // System.Console.WriteLine(c3);

            // int a = 9;
            // //10 = 11
            // int number = (int)Math.Log10(a) + 1;
            // System.Console.WriteLine(number);
            // Console.WriteLine("Hello World!");

            // int t = 10;

            // while( t >= 0)
            // {
            //     System.Console.WriteLine(t);
            //     t--;
            // }
            // System.Console.WriteLine("end");

            // int temp = -1;

            // do
            // {
            //     System.Console.WriteLine(temp);
            //     temp--;
            // }
            // while(temp >= 0);

            // for(int i = 0; i < 10; i++)
            // {
            //     System.Console.WriteLine(i);
            // }



            // for(int i = 10; i >= 0; i--)
            // {
            //     System.Console.WriteLine(i);
            // }

            // while(true)
            // {
            //     System.Console.WriteLine("efe");
            // }

            // for(;;)
            // {
            //     System.Console.WriteLine("ddcds");
            // }

            // int t = 10;
            // int sum = 0;
            // int sum2 = 0;
            
            // for(int i = 0; i <= t; sum+=i++);

            // for(int i = 0; i <= t; i++)
            // {
            //     sum+=i;
            // }

            // for(int i = 0, j = 10; i<=j;i++,j--)
            // {
            //     System.Console.WriteLine($"{i} {j}");
            // }
       
            // int k = 0;
            // for(; k > (-10); k=-2)
            // {
            //     System.Console.WriteLine(k);
            // }


            // System.Console.WriteLine($"My K = {k}");


            // for(int i = 5; i > 0 ; i--)
            // {
            //     for(int j = 5; j > 0; j--)
            //     {
            //         System.Console.Write("*");
            //     }
            //     System.Console.WriteLine();
            // }

            // System.Console.WriteLine(sum);


            // while(true)
            // {
            //     int temp = Convert.ToInt32 (Console.ReadLine());
            //     System.Console.WriteLine(temp);
            //     if(temp == 6)
            //     {
            //         break;
            //     }
            // }

            // for(int i = 0; i < 10; i++)
            // {
            //     if(i % 2 == 1)
            //     {
            //         continue;
            //     }
            //     System.Console.WriteLine(i);
            // }

        // int t = 0;
        // test:
        //     System.Console.WriteLine(t + "HRTRGE");
        //     goto test2;



        // test2:
        // {
        //     while(t < 10)
        //     {
        //         System.Console.WriteLine(t);
        //         if (t % 2 == 0)
        //         {
        //             t++;
        //             goto test;
        //         }
        //         t++;
        //     }
        // }

            

     

        }
    }
}
