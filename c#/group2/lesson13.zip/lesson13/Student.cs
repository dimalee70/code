using System;
namespace lesson13
{
    class Student : Human
    {
        
    }
}