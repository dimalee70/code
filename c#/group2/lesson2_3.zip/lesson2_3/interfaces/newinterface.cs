namespace lesson2_3.interfaces
{
    public interface newinterface
    {
         void Hello();
    }
}