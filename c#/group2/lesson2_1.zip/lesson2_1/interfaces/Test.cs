namespace lesson2_1.interfaces
{
    public interface Test
    {
        //  void SayHello();
         void TestAdd(Person [] oldPersons, Person[] newPersons);
        //  void TestDelite();
    }
}