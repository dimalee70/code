namespace lesson2_1.interfaces
{
    public interface BasePerson
    {
        void PrinPersons();
        void add(Person person);

        void delete(int i);

        // Person edit (int i);
    }
}