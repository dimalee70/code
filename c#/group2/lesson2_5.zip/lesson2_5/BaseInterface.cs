using System;

namespace lesson2_5
{
    public interface BaseInterface
    {
        void hello();
    }
}