using System;
namespace lesson2_8
{
    public interface MyInterface
    {
        void Hello();
    }
}