using System;

namespace lesson12
{
    class HelloClass
    {
        public string hello()
        {
            return "Hello World";
        }
    }     
}