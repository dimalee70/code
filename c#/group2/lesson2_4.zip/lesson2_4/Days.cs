public enum Days
{
    Sunday = 1 ,
    Monday,
    Tuesday ,
    Wednesday,
    Thurday,
    Friday, 
    Satuday
}