using abstracts.models;

namespace abstracts.interfaces
{
    public interface Actions
    {
         void Add(Employee employee);
    }
}