﻿using System;

namespace arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");
            // int n = Convert.ToInt32(Console.ReadLine());
            // int  m = Convert.ToInt32(Console.ReadLine());

            // int temp = 1;
            // for(int i =0 ; i < n; i++)
            // {
            //     for(int j = 0; j < m; j++)
            //     {
            //         System.Console.Write(temp++ + "\t");
            //     }
            //     System.Console.WriteLine();
            // }


            // double []  myIntArray = new double [10];

            // double t = 0.0;
            // System.Console.WriteLine(myIntArray.Length);

            // for(int index = 0;index < myIntArray.Length; index++)
            // {
            //     myIntArray[index] = t++;
            // }


            
            // for(int index = 0;index < myIntArray.Length; index++)
            // {
            //     System.Console.WriteLine(myIntArray[index] + " " + index ) ;
            // }
            // System.Console.WriteLine();

            // foreach(double d in myIntArray)
            // {
            //     System.Console.Write(d + " ");
            // }
            // System.Console.WriteLine();


            // char [] myCharArr = {'w','r','t','u'};

            // char [] myChar = new char[]{'2','4'};

            // object [] myObject = {'a',32,4.56,true};

            // int [] myInt = new int[15];


            // Random rand = new Random();
            // for(int i = 0; i < myInt.Length; i++)
            // {
            //     myInt[i] = rand.Next(15,50);
            // }

            // for (int i = myInt.Length-1; i >= 0; i--)
            // {
            //     System.Console.Write(myInt[i] + " ");
            // }
            // System.Console.WriteLine();


            // int [,] myInt2D = new int[4,6];
            // int temp = 24;

            // System.Console.WriteLine(myInt2D.Length);

            // for(int i = 0; i < myInt2D.GetLength(0); i++)
            // {
            //     for(int j = 0; j < myInt2D.GetLength(1); j++)
            //     {
            //         myInt2D[i,j] = temp--;
            //     }
            // }


            // for(int i = 0; i < myInt2D.GetLength(0); i++)
            // {
            //     for(int j = 0; j < myInt2D.GetLength(1); j++)
            //     {
            //         System.Console.Write(myInt2D[i,j]+"\t");
            //     }
            //     System.Console.WriteLine();
            // }



            // int [,,,] myInt3D = new int [2,3,4,3];
            


            // System.Console.WriteLine("enter the length of array");

            // int size = Convert.ToInt32(Console.ReadLine());
            // int [] myInputArr = new int[size];

            // for(int i = 0; i < size; i++)
            // {
            //     System.Console.WriteLine("Enter element:");
            //     myInputArr[i] = Convert.ToInt32(Console.ReadLine());


            // }


            // foreach(var t in myInputArr)
            // {
            //     System.Console.Write(t+" ");

            // }
            // System.Console.WriteLine();








            // myIntArray[0] = 10;
            // myIntArray[0] = 13;
            // myIntArray[1] = 11;
            // System.Console.WriteLine(myIntArray[0]);
            // System.Console.WriteLine(myIntArray[1]);
            // System.Console.WriteLine(myIntArray[2]);

            




            
            // System.Console.WriteLine(myIntArray);


            
        }
    }
}
