using lesson10.myNamespace;

namespace lesson10.test
{

    public enum myEnum{fgg = 1,ghfg = 2,gfgf=3,gfhfg=4}
    public class newclass
    {
        myTest m;
    }
}