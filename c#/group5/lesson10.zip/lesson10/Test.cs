using System;

namespace lesson10
{
    public class Test
    {
        Program p;

        public void init()
        {
            Program.Main();
        }
    }
}