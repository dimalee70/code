using lesson10.test;

namespace lesson10.myNamespace
{
    class myTest
    {
        Program pr;
        myEnum dds = myEnum.fgg;
    }
}