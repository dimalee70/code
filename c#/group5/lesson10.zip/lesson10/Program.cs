﻿using System;
using lesson10.test;

namespace lesson10
{
    
    class Program
    {
        public static void Main()
        {
            
            

        }
    }
}
